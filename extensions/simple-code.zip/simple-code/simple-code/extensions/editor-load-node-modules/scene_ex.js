/* 
*场景逻辑扩展
*/
'use strict';
var path 	= require('path');
var fs 		= require('fs');
var md5     = require('md5');


module.exports = {
	/*************  事件 *************/  
	messages: 
	{
		'test'(event,args,parent){
			// Editor.log("scene test")
		}
	}
};