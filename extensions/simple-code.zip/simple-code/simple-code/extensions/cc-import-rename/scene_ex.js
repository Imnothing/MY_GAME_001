/* 
*场景逻辑扩展
*代码输入提示
*/
'use strict';
var path 	= require('path');
var fs 		= require('fs');
var md5     = require('md5');
const Editor2D = require('../../tools/editor2D');
const tools 	= Editor2D.require('packages://simple-code/tools/tools.js');


module.exports = {
	/*************  事件 *************/  
	messages: 
	{
	}
};