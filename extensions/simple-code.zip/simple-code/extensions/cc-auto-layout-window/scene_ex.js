/* 
*场景逻辑扩展
*删除选中的节点以及节点所绑定的脚本
*/
'use strict';
var path 	= require('path');
var fs 		= require('fs');


module.exports = {
	
	
	/*************  事件 *************/  
	messages: 
	{
	}
};